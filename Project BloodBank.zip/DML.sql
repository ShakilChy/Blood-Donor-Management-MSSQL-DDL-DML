--------------------------BloodBankDB ---- DML-----------------
use BloodBankDB
insert into BloodBank(BankID,BankName,BankAddress,BankContact,BankEmail)
values
(1,'Quantum Foundation','Shanti Nagar',4585123,'quantum@gmail.com'),
(2,'Red Crescent Society','Maghbazar',5655646,'redcrescentsociety@ymail.com'),
(3,'Badhan Blood Transfusion Center','Secretarial Road',45669978,'badhonbloodtc@gmail.com');
go
insert into Donor(DonorID,DonorName,DonorBloodGroup,Date_of_Birth,[TotalDonation(times)],DonorAddress,DonorContact,Last_Donation)
values
(1,'Shakil','O+','23-Feb-1993',15,'Dhanmondi,Dhaka',5156847,'3 Months ago'),
(2,'Atik','A+','17-Jul-1993',3,'Mohammadpur,Dhaka',51545687,'1 Year ago'),
(3,'Raihan','O-','11-Aug-1989',0,'Uttara,Dhaka',15425486,'Never donated'),
(4,'Bela Bose','B+','09-Mar-1987',5,'Demra,Dhaka',2441139,'6 Months ago');
go
insert into Donation(DonationID,DonorID,PatientName,BloodBankID,DonationDate)
values
(1,4,'Alif',1,'19-Sep-2019'),
(2,1,'Meem',2,'01-Nov-2019'),
(3,2,'Arman',3,'05-Feb-2019');
go
insert into Patient(PatientID,PatientName,PatientBloodGroup,PatientAddress,PatientContact,LastReceivedDate)
values
(1,'Alif','O+','Azimpur','420541','19-Sep-2019'),
(2,'Meem','B+','Cumilla','459841','01-Nov-2019'),
(3,'Arman','O-','Moghbazar','659885','05-Feb-2019');
go
insert into Transfusion(TransfusionID,PatientID,BloodbankID,TransfusionDate)
values
(1,1,1,'19-Sep-2019'),
(2,2,2,'01-Nov-2019'),
(3,3,3,'05-Feb-2019');
go
---------------------------Joining----------------------------
select Donor.DonorName,Donor.DonorBloodGroup,Donor.DonorContact,Donation.DonationDate,BloodBank.BankName from
Donation join Donor on Donation.DonorID=Donor.DonorID join BloodBank on Donation.BloodBankID=BloodBank.BankID
where DonorBloodGroup='O+';
---------------------------------------------------------------
exec SPBBankInsert 5,'Mukta Blood Bank','Shyamoli,Dhaka',256545,'muktablood@hotmail.com'
exec SPBBankDelete 1;

--------------------------------Case-------------------------------
select Donor.DonorBloodGroup 
case when Donor.DonorBloodGroup='O-' 
then 'Rare blood'
else
'Available'
end as Stock_Rarity
from Donor join Donation on Donor.DonorID=Donation.DonorID
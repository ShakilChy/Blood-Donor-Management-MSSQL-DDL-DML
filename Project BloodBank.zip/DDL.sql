create database BloodBankDB
use BloodBankDB
create table BloodBank
(
BankID int primary key not null,
BankName varchar(255),
BankAddress varchar(255),
BankContact numeric,
BankEmail varchar(255)
);

Create table Donor
(
DonorID int primary key,
DonorName varchar(255),
DonorBloodGroup varchar(5),
Date_of_Birth date,
[TotalDonation(times)] int,
DonorAddress varchar(255),
DonorContact numeric,
Last_Donation varchar(50)
);
create table Donation
(
DonationID int primary key not null,
DonorID int references Donor(DonorID),
PatientName varchar(255),
BloodBankID int references BloodBank(BankID),
DonationDate varchar(50)
);
Create table Patient
(
PatientID int primary key not null,
PatientName varchar(255),
PatientBloodGroup varchar(5),
PatientAddress varchar(255),
PatientContact numeric,
LastReceivedDate varchar(50),
Disease varchar(50),
);
Create table Transfusion
(
TransfusionID int primary key not null,
PatientID int references Patient(PatientID),
BloodbankID int references BloodBank(BankID),
TransfusionDate varchar(50)
);
------Trigger Table---------
Create table Donation_Records
(
RecordID int primary key nonclustered not null identity,
DonationID int references Donation_info(DonationID),
DonationDate varchar(50),
DonorName varchar(255),
Details varchar(255),
PatientName varchar(255),
BloodBankName varchar(255)
);
-----------------Stored Procedure------------
Create proc SPBBankInsert
@BankID int,
@BankName varchar(255),
@BankAddress varchar(255),
@BankContact numeric,
@BankEmail varchar(255)
as
insert into
BloodBank (BankID,BankName,BankAddress,BankContact,BankEmail)
values (@BankID,@BankName,@BankAddress,@BankContact,@BankEmail);


Create proc SPBBankUpdate
@BankID int,
@BankName varchar(255),
@BankAddress varchar(255),
@BankContact numeric,
@BankEmail varchar(255)
as
update
BloodBank set BankName=@BankName, BankAddress=@BankAddress, BankContact=@BankContact,BankEmail=@BankEmail where BankID=@BankID;



Create proc SPBBankDelete
@BankID int
as
delete from BloodBank where BankID=@BankID;
exec SPBBankDelete 1;
---------------------CTE------------
WITH CTE_Donor_Age (DonorName, DonorBloodGroup, Date_of_Birth,Donor_Age) AS
(
    SELECT    
        D.DonorName,
D.DonorBloodGroup,
        D.Date_of_Birth,
GETDATE(),
        YEAR(GETDATE()) - YEAR(D.Date_of_Birth)
    FROM Donor D
)
SELECT
    DonorName,
DonorBloodGroup,
    Date_of_Birth
FROM
    CTE_Donor_Age
WHERE
   Donor_Age >= 18;

---------MERGE------------
Create table Merge_Transfusion
(
TransfusionID int primary key not null,
PatientID int references Patient(PatientID),
BloodbankID int references BloodBank(BankID),
TransfusionDate varchar(50)
);

MERGE INTO Transfusion AS T
USING Merge_Transfusion AS MT
        ON T.TransfusionID = MT.TransfusionID
WHEN MATCHED THEN
    UPDATE SET
      T.PatientID = MT.PatientID,
      T.BloodbankID = MT.BloodbankID
WHEN NOT MATCHED THEN
      INSERT (TransfusionID, PatientID, BloodbankID, TransfusionDate )
      VALUES (MT.TransfusionID, MT.PatientID, MT.BloodbankID, MT.TransfusionDate );
-----------------------------Trigger--------------------
CREATE TRIGGER Trg_DRecord
ON Donation
AFTER UPDATE, INSERT, DELETE
AS
DECLARE @RecordID INT, 
@DonationID int ,
@DonationDate varchar(50), 
@DonorName varchar(255),
@Details varchar(255),
@PatientName varchar(255),
@BloodBankName varchar(255);
IF EXISTS(SELECT * FROM inserted) and exists (SELECT * FROM deleted)
BEGIN
    SELECT @RecordID = u.RecordID,@DonationID=u.DonationID, @DonationDate = u.DonationDate, @PatientName = u.@PatientName FROM inserted u;
    INSERT INTO Donation_Records(DonationID,DonationDate, DonorName, Details, PatientName ,BloodBankName)
	VALUES(@DonationID,getdate(), @DonorName, 'Record Updated', @PatientName ,@BloodBankName);
	PRINT('Trigger fired after UPDATE');
END
IF exists (SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)
BEGIN
    SELECT @RecordID = i.RecordID,@DonationID=i.DonationID, @DonationDate = i.DonationDate, @PatientName = i.@PatientName FROM inserted i;
    INSERT INTO Donation_Records(DonationID,DonationDate, DonorName, Details, PatientName ,BloodBankName)
	VALUES(@DonationID,getdate(), @DonorName, 'Record Inserted', @PatientName ,@BloodBankName);
	PRINT('Trigger fired after Insert');
END
IF EXISTS(select * from deleted) AND NOT EXISTS(SELECT * FROM inserted)
BEGIN
    SELECT @RecordID = d.RecordID,@DonationID=d.DonationID, @DonationDate = d.DonationDate, @PatientName = d.@PatientName FROM inserted d;
    INSERT INTO Donation_Records(DonationID,DonationDate, DonorName, Details, PatientName ,BloodBankName)
	VALUES(@DonationID,getdate(), @DonorName, 'Record Deleted', @PatientName ,@BloodBankName);
	PRINT('Trigger fired after DELETE');
END
GO
-----------------------Instead of trigger-------------
CREATE TRIGGER dbo.Trg_Transfussion
ON dbo.Transfussion
INSTEAD OF UPDATE
AS
BEGIN
DECLARE @TransfusionID int, @PatientID int, @BloodbankID int, @TransfusionDate varchar(50);
SELECT @TransfusionID = inserted.TransfusionID,
@PatientID = inserted.PatientID,
@BloodbankID = inserted.BloodbankID,
@TransfusionDate = inserted.TransfusionDate      
FROM inserted
if UPDATE(PatientID)
BEGIN
RAISERROR('Sorry this record cannot be updated.', 16 ,1)
ROLLBACK
END
ELSE
BEGIN
UPDATE [Transfussion]
SET PatientID = @PatientID WHERE TransfusionID = @TransfusionID
END
END
---------------------------------------------------------

